package co.edu.uniquindio.poo;

import java.time.LocalDate;

import java.time.Period;


public class Edad {
    private LocalDate fechaNacimiento;
    private LocalDate fechaActual;
        


    public Edad(LocalDate fechaNacimiento, LocalDate fechaActual) {
        this.fechaNacimiento = fechaNacimiento;
        this.fechaActual = fechaActual;
    }

    public LocalDate getFechaNacimiento() {
        return fechaNacimiento;
    }

    public void setFechaNacimiento(LocalDate fechaNacimiento) {
        this.fechaNacimiento = fechaNacimiento;
    }

    public LocalDate getFechaActual() {
        return fechaActual;
    }

    public void setFechaActual(LocalDate fechaActual) {
        this.fechaActual = fechaActual;
    }

   
    public static int calcularEdad(LocalDate fechaNacimiento) {
        LocalDate fechaActual = LocalDate.now();
        Period period = Period.between(fechaNacimiento, fechaActual);
        return period.getYears();
    }
}
