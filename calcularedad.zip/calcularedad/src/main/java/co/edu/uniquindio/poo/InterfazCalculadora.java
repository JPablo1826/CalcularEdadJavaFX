package co.edu.uniquindio.poo;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDate;
import java.time.Month;
import java.util.Arrays;

public class InterfazCalculadora {
    public static void main(String[] args) {

        // Crea un JFrame para contener la GUI
        JFrame frame = new JFrame("Calculadora de edad");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(300, 200);

        // Crea un JPanel para contener los componentes de la GUI
        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(5, 2));

        // Crear JComboBoxes por día, mes y año
        JComboBox<String> dayComboBox = new JComboBox<>(generarNumeros(1, 31));
        JComboBox<String> monthComboBox = new JComboBox<>(generarNombreMeses());
        JComboBox<String> yearComboBox = new JComboBox<>(generarNumeros(1900, LocalDate.now().getYear()));

        // Cree un JButton para que el usuario haga clic para calcular su edad.
        JButton calculateButton = new JButton("Calcular edad");

        // Crea una etiqueta para mostrar la edad del usuario
        JLabel ageLabel = new JLabel("Tu edad aparecerá aquí.");

        panel.add(new JLabel("Día:"));
        panel.add(dayComboBox);
        panel.add(new JLabel("Mes:"));
        panel.add(monthComboBox);
        panel.add(new JLabel("Año:"));
        panel.add(yearComboBox);
        panel.add(new JLabel()); 
        panel.add(calculateButton);
        panel.add(new JLabel()); 
        panel.add(ageLabel);

       // Crea un ActionListener para el botón calcular
        ActionListener calculateListener = new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    // Obtener el día, mes y año seleccionados de JComboBoxes
                    int day = Integer.parseInt((String) dayComboBox.getSelectedItem());
                    int month = monthComboBox.getSelectedIndex() + 1; // Indices de 0 a 11
                    int year = Integer.parseInt((String) yearComboBox.getSelectedItem());

                    // Crear objeto LocalDate a partir de la fecha seleccionada
                    LocalDate fechaNacimiento = LocalDate.of(year, month, day);

                    // Verificar si la fecha de nacimiento es válida
                    if (fechaNacimiento.isAfter(LocalDate.now())) {
                        throw new IllegalArgumentException(
                                "La fecha de nacimiento no puede ser después de la fecha actual.");
                    }

                    //Calcular la edad del usuario
                    int edad = Edad.calcularEdad(fechaNacimiento);

                    // Muestra la edad del usuario en un JLabel
                    JOptionPane.showMessageDialog(frame, "Tu edad es: " + edad);

                    // Cerra la ventana actual
                    frame.dispose();

                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(frame, "Por favor, seleccione una fecha válida.", "Error",
                            JOptionPane.ERROR_MESSAGE);
                } catch (IllegalArgumentException ex) {
                    JOptionPane.showMessageDialog(frame, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        };

        // Agrega ActionListener al botón de calcular
        calculateButton.addActionListener(calculateListener);

        // Agrega el JPanel al JFrame
        frame.add(panel);

        //Hacer visible el JFrame
        frame.setVisible(true);

    }

    // Método para generar un array de cadenas que representan números dentro de un rango
    private static String[] generarNumeros(int start, int end) {
        String[] numbers = new String[end - start + 1];
        for (int i = start; i <= end; i++) {
            numbers[i - start] = Integer.toString(i);
        }
        return numbers;
    }

   // Método para generar un array de cadenas que representan nombres de meses
    private static String[] generarNombreMeses() {
        return Arrays.stream(Month.values())
                .map(Enum::toString)
                .map(String::toLowerCase)
                .map(s -> s.substring(0, 1).toUpperCase() + s.substring(1))
                .toArray(String[]::new);
    }
}
